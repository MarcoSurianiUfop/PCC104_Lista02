/******************************************************************************
                    PCC104 - PROJETO E ANÁLISE DE ALGORITMOS
                  LISTA 2 - ATIVIDADES PRÁTICAS - EXERCÍCIO 09

                              Breadth-First Search

    Aluno: MARCO AURÉLIO MOURA SURIANI - 2021.10177
*******************************************************************************/

#include <iostream>
#include <vector>

using namespace std;

void bfs(std::vector<int>& G, int& nodes, int& nvertex, int& v,
    std::vector<int>& visited_vertex, int& count)
{
    count++;
    visited_vertex[v] = count;

    std::vector<int> bfs_queue;
    int bfs_queue_begin = 0;
    bfs_queue.push_back(v);

    int w;

    while (bfs_queue.size() > bfs_queue_begin)
    {
        for (int j = 0; j < nvertex; j++)
        {
            w = G[2 * j + 1];
            if (G[2 * j] == bfs_queue[bfs_queue_begin] && visited_vertex[w] == 0)
            {
                count++;
                // mark w with count
                visited_vertex[w] = count;
                // add w to the queue
                bfs_queue.push_back(w);
            }
        }
        // remove the front vertex from the queue
        bfs_queue_begin++;
    }
}

std::vector<int> BFS(std::vector<int> G, int nodes, int nvertex)
{
    std::vector<int> visited_vertex;
    for (int i = 0; i < nodes; i++)
        visited_vertex.push_back(0);

    int count = 0;

    for (int v = 0; v < nodes; v++)
    {
        if (visited_vertex[v] == 0)
            bfs(G, nodes, nvertex, v, visited_vertex, count);
    }
    return visited_vertex;
}

// Driver program to test above functions  
int main()
{
    // Create a vector containing integers
    // Vertex must be in ascending order (lower node, greater node)
    std::vector<int> G = { 0, 1, 0, 3, 1, 2, 2, 3, 2, 10,
                          3, 4, 3, 6, 4, 8, 6, 7, 5, 9 };
    int nvertex = G.size() / 2, nodes = 11;

    cout << "01 --- 00     05 --- 09" << endl;
    cout << "|      |" << endl;
    cout << "02 --- 03 --- 04 --- 08" << endl;
    cout << "|      |" << endl;
    cout << "10     06 --- 07" << endl << endl;

    cout << "NDS: ";
    for (int i = 0; i < nodes; i++)
        cout << i << " , ";
    cout << endl;

    std::vector<int> BFS_G = BFS(G, nodes, nvertex);

    cout << "BFS: ";
    for (int i = 0; i < nodes; i++)
        cout << BFS_G[i] << " , ";

    return 0;

}