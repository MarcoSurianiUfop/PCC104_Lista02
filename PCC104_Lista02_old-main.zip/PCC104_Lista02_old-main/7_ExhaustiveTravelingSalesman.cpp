/******************************************************************************
                    PCC104 - PROJETO E ANÁLISE DE ALGORITMOS
                  LISTA 2 - ATIVIDADES PRÁTICAS - EXERCÍCIO 07

                            Traveling Salesman Problem

    Aluno: MARCO AURÉLIO MOURA SURIANI - 2021.10177
*******************************************************************************/

#include <iostream>
#include <vector>
#include <algorithm>
//#include <bits/stdc++.h>

using namespace std;

// implementation of traveling Salesman Problem
int exhaustiveTravelingSalesmanProblem(vector<vector<int>> graph, int n, int s)
{
    // store all vertex apart from source vertex
    vector<int> vertex;
    for (int i = 0; i < n; i++)
        if (i != s)
            vertex.push_back(i);

    // store minimum weight Hamiltonian Cycle.
    int min_path = INT_MAX;
    do {

        // store current Path weight(cost)
        int current_pathweight = 0;

        // compute current path weight
        int k = s;

        for (int i = 0; i < n - 1; i++) {
            current_pathweight += graph[k][vertex[i]];
            k = vertex[i];
        }
        current_pathweight += graph[k][s];

        cout << s;
        for (int i = 0; i < n - 1; i++) cout << " , " << vertex[i];
        cout << " -> " << current_pathweight << endl;

        // update minimum
        min_path = min(min_path, current_pathweight);

    } while (
        next_permutation(vertex.begin(), vertex.end()));

    return min_path;
}

// Driver program to test above functions  
int main()
{
    // Create a vector containing integers
    vector< vector<int> > P = { { 0, 10, 15, 20 },
                                          { 10, 0, 35, 25 },
                                          { 15, 35, 0, 30 },
                                          { 20, 25, 30, 0 } };
    int n = P.size(), s = 1;
    cout << "Minimum Path: " << exhaustiveTravelingSalesmanProblem(P, n, s) << endl;
    return 0;
}

