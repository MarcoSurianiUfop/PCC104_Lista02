/******************************************************************************
                    PCC104 - PROJETO E ANÁLISE DE ALGORITMOS
                  LISTA 2 - ATIVIDADES PRÁTICAS - EXERCÍCIO 08

                                Knapsack Problem

    Aluno: MARCO AURÉLIO MOURA SURIANI - 2021.10177
*******************************************************************************/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// Returns the maximum value that
// can be put in a knapsack of capacity W
vector<vector<int>> exhaustiveKnapSackProblem(vector<vector<int>> itens, int n, int W) {
    // store all vertex apart from source vertex
    std::vector<int> index;
    for (int i = 0; i < n; i++)
        index.push_back(i);

    int cumulative_weight, cumulative_value, itens_size;

    std::vector<int> current_knap;
    std::vector<std::vector<int>> current_maximum = { {0},{} };

    do {

        cumulative_weight = 0;
        cumulative_value = 0;
        itens_size = 0;

        current_knap = {};

        while (cumulative_weight + itens[0][index[itens_size]] <= W)
        {
            cumulative_weight += itens[0][index[itens_size]];
            cumulative_value += itens[1][index[itens_size]];
            current_knap.push_back(index[itens_size]);
            itens_size++;
        }

        if (cumulative_value > current_maximum[0][0])
        {
            current_maximum[0][0] = cumulative_value;
            current_maximum[1] = current_knap;
        }

    } while (next_permutation(index.begin(), index.end()));

    return current_maximum;
}

// Driver program to test above functions  
int main()
{
    // Create a vector containing integers
    vector< vector<int> > V = { { 14,  6,  8, 10 },
                                          { 42, 12, 40, 25 } };
    int n = V[0].size(), W = 20;

    vector< vector<int> > max_knap = exhaustiveKnapSackProblem(V, n, W);

    cout << "Maximum Value: " << max_knap[0][0] << endl;
    cout << "Itens: ";
    for (int i = 0; i < max_knap[1].size(); i++)
        cout << max_knap[1][i] + 1 << " , ";

    return 0;
}
